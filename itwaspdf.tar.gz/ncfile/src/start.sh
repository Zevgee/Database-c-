#!/bin/sh 

cd /ctf
/usr/local/bin/python srv.py
